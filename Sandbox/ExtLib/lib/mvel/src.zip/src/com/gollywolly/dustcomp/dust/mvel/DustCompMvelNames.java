package com.gollywolly.dustcomp.dust.mvel;

import com.gollywolly.dustcomp.DustCompUtils;
import com.gollywolly.dustcomp.DustCompComponents.DustIdentifier;
import com.gollywolly.dustcomp.api.DustCompApiNames;

public interface DustCompMvelNames extends DustCompApiNames {
	DustIdentifier FLD_EXPRESSION = DustCompUtils.getPathBuilder().simpleId("expression");
	DustIdentifier PARAM_CHILDREN = DustCompUtils.getPathBuilder().combine(new DustIdentifier[] { CTX_PARAM, TYPE_CONTAINER, FLD_CHILDREN });
	DustIdentifier VISIT_VARTEXT = DustCompUtils.getPathBuilder().combine(new DustIdentifier[] { CTX_VISIT, TYPE_VARIANT, VT_TEXT});
	DustIdentifier VISIT_NATIVE = DustCompUtils.getPathBuilder().combine(new DustIdentifier[] { CTX_PARAM, TYPE_WRAPPER, FLD_NATIVE});
	
	String VAL_MODE_MULTI = "multi";

}
