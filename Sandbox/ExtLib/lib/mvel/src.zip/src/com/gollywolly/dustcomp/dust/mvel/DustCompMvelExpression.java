package com.gollywolly.dustcomp.dust.mvel;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.mvel2.MVEL;
import org.mvel2.ParserContext;
import org.mvel2.integration.impl.MapVariableResolverFactory;

import com.gollywolly.dustcomp.DustCompComponents;
import com.gollywolly.dustcomp.DustCompServices.DustUtilsBlock;
import com.gollywolly.dustcomp.DustCompServices.DustUtilsEvaluator;
import com.gollywolly.dustcomp.DustCompServices.DustUtilsStateful;
import com.gollywolly.dustcomp.DustCompUtils;
import com.gollywolly.dustcomp.api.DustCompApiUtils;
import com.gollywolly.dustcomp.coll.DustCompUtilsLazyCreator;

public class DustCompMvelExpression implements DustCompMvelNames, DustUtilsEvaluator, DustUtilsStateful, DustUtilsBlock, DustCompComponents {
	private static DustIdentifierFactory idFact = DustCompApiUtils.getPathBuilder();

	private static ParserContext pctx = new ParserContext();

	static {
		pctx.addPackageImport("com.continental.platform.common");
		// pctx.addImport(ProcessAction.class);
		//
		// try {
		// Instance cfg =
		// CPCommonUtils.getRuntime().getRootCloud().evokeSharedInstance("MVELConfig");
		// // Instance cfg = CPCommonUtils.evokeInstance("MVELConfig", null);
		//
		// if (null != cfg) {
		// scriptRoot = cfg.getValue("scriptRoot", scriptRoot);
		// }
		// } catch (Exception e) {
		// throw new CPCommonException("MVEL initialization exception", e);
		// }
	}

	static class ApiWrapper {

	}

	class ParamWrapper {
		DustIdentifier[] access;

		public ParamWrapper(DustIdentifier wrapId) {
			access = new DustIdentifier[] { wrapId, null };
		}

		public Object get(String id, Object defValue) {
			access[1] = idFact.smartId(id);
			Object ret = DustCompApiUtils.getValue(idFact.combine(access));

			return (null == ret) ? defValue : ret;
		}

		public void set(String id, Object value) {
			access[1] = idFact.smartId(id);
			DustCompApiUtils.setValue(idFact.combine(access), value);
		}
	}

	boolean multi;
	private static final ApiWrapper apiWrapper = new ApiWrapper();

	Serializable exprComp;
	DustCompUtilsLazyCreator exprContainer;

	Map<String, Object> varMap = new HashMap<String, Object>();
	MapVariableResolverFactory varFact = new MapVariableResolverFactory(varMap);

	@Override
	public void dust_utils_stateful_init() throws Exception {
		multi = VAL_MODE_MULTI.equals(DustCompApiUtils.getValue(FLD_MODE));

		if (multi) {
			exprContainer = new DustCompUtilsLazyCreator(new DustFactory() {
				public Object create(Object key) {
					return MVEL.compileExpression((String) key, pctx);
				}
			});
		} else {
			String mvelContent = (String) DustCompApiUtils.getValue(FLD_EXPRESSION);
			exprComp = MVEL.compileExpression(mvelContent, pctx);
		}
		varMap.clear();

		varMap.put("api", apiWrapper);
		DustCompApiUtils.visit(PARAM_CHILDREN, new DustValueVisitorDefault() {
			@Override
			protected void process(Object value, int idx) throws Exception {
				String name = (String) DustCompApiUtils.getValue(VISIT_VARTEXT);
				DustIdentifier id = (DustIdentifier) DustCompApiUtils.getValue(VISIT_NATIVE);
				varMap.put(name, new ParamWrapper(id));
			}
		});
	}

	@Override
	public void dust_utils_block_start() throws Exception {
		DustCompApiUtils.setValue(VT_LINK, DustCompApiUtils.getParamValue(VAR_LINK));
	}

	@Override
	public void dust_utils_evaluator_evaluate() throws Exception {
		Object expr;

		if (multi) {
			Object key = DustCompApiUtils.getParamValue(VAR_TEXT);
			expr = exprContainer.get(key);
		} else {
			expr = exprComp;
		}

		Object ret = MVEL.executeExpression(expr, this);
		DustCompApiUtils.setParamValue(FLD_RESPONSE, ret);
	}

	@Override
	public void dust_utils_block_end() throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void dust_utils_stateful_release() throws Exception {
		varMap.clear();
	}

	public Object get(String path) {
		Object ret = DustCompApiUtils.getValue(CTX_THIS, VT_LINK, idFact.smartId(path));
		return DustCompUtils.safeToString(ret, "-");
	}
}
